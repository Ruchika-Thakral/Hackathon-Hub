import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";

const initialState = {
    hackathons:{
        data:null,
        loading:false,
        error:null
    }
};
export const fetchHackathons=createAsyncThunk(
    'hackathon/fetchHackathons',
    async (thunkAPI) => {
        try {
            const response = await axios.get('http://localhost:8080/Hackathon/all');
            return response;
        } catch (error) {
            return thunkAPI.rejectWithValue(error.response.data);
        }
    }
);

const hackathonSlice = createSlice({
    name: "hackathon",
    initialState,
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchHackathons.pending, (state) => {
                state.hackathons.loading = true;
                state.hackathons.error = null;
            })
            .addCase(fetchHackathons.fulfilled, (state, action) => {
                state.hackathons.loading = false;
                state.hackathons.data = action.payload; // Extract data from the response
                state.hackathons.error = null;
            })
            .addCase(fetchHackathons.rejected, (state, action) => {
                state.hackathons.loading = false;
                state.hackathons.data= null;
                state.hackathons.error = action.payload; // Set error payload
            })
        }
});



export default hackathonSlice.reducer;
